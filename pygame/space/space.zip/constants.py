import pygame

screen=pygame.display.set_mode()
SCREEN_WIDTH=screen.get_width()
SCREEN_HEIGHT=screen.get_height()
FPS=60